module.exports = async function() {
    console.log("Bot bağlantısı kesildi!");
}

module.exports.conf = {
    name: "disconnect"
}
