module.exports = async function() {
    console.log("Bot Tekrar Bağlanıyor!")
}

module.exports.conf = {
    name: "reconnecting"
}
